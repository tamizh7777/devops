# Kubernetes Engine Quickstart

Please follow the [Deploying a language-specific app][quickstart] quickstart to
run the code in this directory.

[quickstart]: https://cloud.google.com/kubernetes-engine/docs/quickstarts/deploying-a-language-specific-app

